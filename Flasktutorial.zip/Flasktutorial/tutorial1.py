from flask import Flask, redirect, url_for

app = Flask(__name__)    #creating an instance of Flask, assigning it to app
#__name__ is variable for name of package or module?

@app.route("/")       #needed to route the contents of the function to homepage
def home():
    return "Hello, this is main page  <h1>YERDANA<h1>"

@app.route("/<name>")       #name is getting passed on to the function
def user(name):
    return "hello {name}"

@app.route("/admin")
def admin():
    return redirect(url_for("home"))
    #redirects to home page (function home) 

if __name__ == "__main__":      #code to run the app
    app.run()
