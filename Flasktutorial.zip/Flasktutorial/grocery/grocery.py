def main():
    
    newlist = gr_list()
    newlist.sort()

    for a in newlist:
        print(newlist.count(a),a.upper())
    



def gr_list():
    groceries = []
    while True:
        try:
            groceries.append(input("Enter: "))
        except EOFError:
            return groceries
    


main()