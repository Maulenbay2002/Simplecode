def main():
    print(is_outdated())

def is_outdated():
    my_dict = {
    "January" : '1',
    "February" : '2',
    "March" : '3',
    "April" : '4',
    "May" : '5',
    "June" : '6',
    "July" : '7',
    "August" : '8',
    "September" : '9',
    "October" : '10',
    "November" : '11',
    "December" : '12'
    }

    while True:
            try:
                x = input("Date: ")
                if ',' in x:
                    parts = x.split(',')       #['September 8' '2005']
                    month_day = parts[0].split()  # ['September', '8']
                    year = parts[1].strip()
                    month_day[0] = my_dict[month_day[0]]
                    return year + "-" + month_day[0] + "-" + month_day[1]
            except KeyError:
                pass
               
                
            else:
                datelist = x.split("/")
                return datelist[2] + "-" + datelist[0] + "-" + datelist[1]
        

# I have to check for the order of the input


        

        
        




main()