name  = input("what si your name? ")

print("my name is " + name)
