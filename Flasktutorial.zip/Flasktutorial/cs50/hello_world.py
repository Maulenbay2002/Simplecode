

a = "yerdana"


print(f"hello world {a}")
